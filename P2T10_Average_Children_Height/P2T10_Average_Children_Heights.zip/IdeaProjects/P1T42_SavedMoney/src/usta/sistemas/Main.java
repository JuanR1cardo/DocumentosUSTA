package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/* AUTHOR: Juan Ricardo Torres Céspedes
	   DATE: 01/04/2020
	   DESCRIPTION: determines how much money a person saves in a year if you consider that each week you save 15% of your salary.
	 */
	Scanner keyboard= new Scanner(System.in);
	f_menu();
	System.out.println("input your salary");
	int salary= keyboard.nextInt();
	f_saved_money(salary);
        }
        //Description: show the menu
        System.out.println("----------------------------------");
        System.out.println(".       SoftSaveMoney            .");
        System.out.println(".       Version: 1.0             .");
        System.out.println(". Made by: Juan Ricardo Torres C..");

    public static void f_menu;() {
        public static void f_saved_money;(int p_salary) {
            // Description: This method /function calculates the total saved money in a year.
            double saved_money=((p_salary*0.15)*4)*12;
            System.out.println("The total saved money in  a year is:" + "saved_money");
	}
}
