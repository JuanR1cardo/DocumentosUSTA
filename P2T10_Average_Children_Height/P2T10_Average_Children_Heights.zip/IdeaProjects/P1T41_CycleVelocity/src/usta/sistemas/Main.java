package usta.sistemas;
import java.sql.SQLOutput;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// AUTHOR: Juan Ricardo Torres Céspedes
    // DATE: 31/03/2020
    // DESCRIPTION:: This software determines the time it takes a person to get from one city to another by bicycle.
    Scanner keyboard= new Scanner(System.in);
    System.out.println("--------------Soft Velocity-----------");
    System.out.println("                                      ");
    System.out.println(" Made by Juan Ricardo Torres Céspedes ");
    System.out.println("--------------------------------------");
    double velocity;
    System.out.println("input the constant velocity (km/h):");
    velocity=keyboard.nextDouble();
    f_time(velocity);

    }
    public static void f_time(double velocity) {
     Scanner keyboard= new Scanner(System.in);
     double time, distance;
     System.out.println("input the distance between two cities: (km)");
     distance=keyboard.nextDouble();
     time= distance/velocity;
     System.out.println("the time is: " + time + " hours");
    }





}
