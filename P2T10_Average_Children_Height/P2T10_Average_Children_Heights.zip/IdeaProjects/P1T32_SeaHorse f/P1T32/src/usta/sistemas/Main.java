package usta.sistemas;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Juan Ricardo Torres
	  DATE: 10/03/2020
	  DESCRIPTION: This program draws a Sea Horse
	 */
		System.out.println("-------$$$$--------------");
		System.out.println("-----$$$$$$$$$$$$$-------");
		System.out.println("----$$$$$$$$$$__$$-------");
		System.out.println("----$$$$$$$$$$$$$$$$$$---");
		System.out.println("-----$$$$$$$$$$$---------");
		System.out.println("-----$$$$$$$-------------");
		System.out.println("-----$$$$$$$$$$$---------");
		System.out.println("------$$$$$$$$$$$$-------");
		System.out.println("------$$$$$$$$$$$$$-----");
		System.out.println("--------$$$$$$$$$$$$$----");
		System.out.println("----------$$$$$$$$$$$$---");
		System.out.println("------------$$$$$$$$$$$$-");
		System.out.println("-------------$$$$$$$$$$$-");
		System.out.println("------------$$$$$$$$$$$$$");
		System.out.println("----------$$$$$$$$$$$$---");
		System.out.println("-----$$$$$$$$$$$---------");
		System.out.println("-----$$$$$$$$$-----------");
		System.out.println("-----$$$$$$$$------------");
		System.out.println("-------$$$$$$$-----------");
		System.out.println("---------$$$$$-----------");
		System.out.println("----------$$$$$$---------");
		System.out.println("------------$$$$$--------");
		System.out.println("-------------$$$$---$$$--");
		System.out.println("---------------$$$$$$$---");
		System.out.println("-----------------$$$$----");




    }
}
