package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        /*AUTHOR: Juan Ricardo Torres Céspedes
	    DATE: 13/04/2020
	    DESCRIPTION: This program calculates geometric areas of determined figures.*/
    }
    f_menu();
    // A esta función NO le ingresan parámetros y no me retorna algo
    public static void f_menu(){
        //Description: this method show the menu of this software
        System.out.println("-----------------------");
        System.out.println("|   SoftAverageHeight |");
        System.out.println("|Version 1.0 20200413 |");
        System.out.println("|Created by: JRTC     |");
        System.out.println("-----------------------");




}

