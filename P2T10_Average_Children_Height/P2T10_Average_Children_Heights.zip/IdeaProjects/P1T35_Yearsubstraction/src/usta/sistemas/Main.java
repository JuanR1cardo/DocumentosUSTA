package usta.sistemas;

import java.util.Scanner;

public class Main {
    /* AUTHOR: Juan Ricardo Torres Céspedes
       DATE: 12/03/2020
       DESCRIPTION: This program calculates the subtraction of two years
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int year1, year2, difference;

        System.out.println("This program calculates the subtraction of two years, enter the first birth year: ");
        year1 = keyboard.nextInt();
        System.out.println("Enter the second birth year: ");
        year2 = keyboard.nextInt();

        difference = year1 - year2;
        System.out.println("The difference between the birth years is: " + difference + " years");

    }
}
