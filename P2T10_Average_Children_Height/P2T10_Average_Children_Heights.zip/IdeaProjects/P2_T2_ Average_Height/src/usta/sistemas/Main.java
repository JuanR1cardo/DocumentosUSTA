package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    /*AUTHOR: Juan Ricardo Torres Céspedes
	    DATE: 13/04/2020
	    DESCRIPTION: This program calculates the average height of a group of 5 children*/
        f_menu();
        double sumatory= f_sum_height();
        System.out.println("The summatory is: "+sumatory+ " mts");
        f_average(sumatory);

    }
    // A esta función NO le ingresan parámetros y no me retorna algo
    public static void f_menu(){
        //Description: this method show the menu of this software
        System.out.println("-----------------------");
        System.out.println("|   SoftAverageHeight |");
        System.out.println("|Version 1.0 20200413 |");
        System.out.println("|Created by: JRTC     |");
        System.out.println("-----------------------");

    }
    // A esta función NO le ingresan parámetros y SÍ me retorna un double
    public static double f_sum_height(){
        //Description: this method calculates the summatory of 5 height
        Scanner keyboard = new Scanner(System.in);
        double sumatory, height1,height2,height3, height4, height5;
        System.out.println("Input the first height (mts):");
        height1=keyboard.nextDouble();
        System.out.println("Input the second height (mts):");
        height2=keyboard.nextDouble();
        System.out.println("Input the third height (mts):");
        height3=keyboard.nextDouble();
        System.out.println("Input the fourth height (mts):");
        height4=keyboard.nextDouble();
        System.out.println("Input the fifth height (mts):");
        height5=keyboard.nextDouble();
        sumatory=height1+height2+height3+height4+height5;
        return sumatory;


    }
    // A esta función SÍ le ingresan parámetros y NO me retorna algo
    public static void f_average(double sumatory){
        //Description: This method calculates the average
        double average= sumatory/5;
        System.out.println("The average is: "+average+ " (mts)");
    }
}
