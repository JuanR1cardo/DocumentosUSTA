package sistemas;

public class Main {

    public static void main(String[] args) {
	// write your code here
        form_menu form_menu1 = new form_menu();

    }
}
