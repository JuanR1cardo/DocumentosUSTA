package usta.sistemas;

public class Main {

    public static void main(String[] args, char target) {
	/* AUTHOR: Juan Ricardo Torres Céspedes
	   DATE: 30/03/2020
	   DESCRIPTION: This software change some letters of a name, also it replace some letters for others
	 */
	String name;
	System.out.println("╔----------------------------------------╗");
	System.out.println("║ String Soft USTA 2020                  ║");
	System.out.println("║ Versión 1.0                            ║");
	System.out.println("║ Creado por Juan Ricardo Torres Céspedes║");
	System.out.println("╚----------------------------------------╝");
	System.out.println("please write your name");
	name= keyboard.nextline();
	if (name.length(<6)) {
    }
        { System.out.println("Error: the name is very short, you have to write your full name (name and surname");

        }
	if (name.length(>20)) {
        }
        {System.out.println("Error: the name is too long, you only have to write you full name (name and surname)");
        }
        System.out.println(name.replace("a", "@");
        System.out.println(name.replace("e", "3");
        System.out.println(name.replace("i", "1");
        System.out.println(name.replace("o", "0");















    }
}
