package usta.sistemas;

import java.util.Scanner;

public class Main {
    /* AUTHOR: Juan Ricardo Torres Céspedes
       DATE: 12/03/20
       DESCRIPTION: This program adds two variables
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int n1, n2, result;

        System.out.println("This software adds two variables, Enter the first variable: ");
        n1 = keyboard.nextInt();
        System.out.println("Enter the second variable");
        n2 = keyboard.nextInt();

        result = n1 + n2;
        System.out.println("The result of this operation is: " + result);
    }
}
