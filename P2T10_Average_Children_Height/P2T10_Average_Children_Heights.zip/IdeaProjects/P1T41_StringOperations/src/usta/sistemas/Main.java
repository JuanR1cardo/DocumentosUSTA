package usta.sistemas;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	//   AUTHOR: Juan Ricardo Torres Céspedes
    //   DATE: 26/03/20
    //   DESCRIPTION: This software makes operations with strings.
        Scanner keyboard= new Scanner(System.in);
        System.out.println("---------------------------");
        System.out.println("        OperationsMaker    ");
        System.out.println("----------------------------");
        System.out.println("input your name: ");
        String name = keyboard.nextLine();
        if(name.indexOf("gomez")!= -1{
            System.out.println("gomez already exists");
        }else{
            System.out.println("gomez doesn´t exist");
        }
        System.out.println("The upper name is " +name.toUpperCase());
        System.out.println(name.replace(  "a", replacement "@"));
        System.out.println(name.substring(7,12));


    }
}
