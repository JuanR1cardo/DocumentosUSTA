package usta.sistemas;

import java.util.Scanner;

public class Main {
/* AUTHOR: Juan Ricardo Torres Céspedes
   DATE: 12/03/2020
   DESCRIPTION: This software sum three variables and calculate its average
     */
public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int n1, n2, n3, sum;
    double average;

    System.out.println("This programs calculate the sum and the average of three numbers, enter the first number: ");
    n1 = keyboard.nextInt();
    System.out.println("Enter the second number: ");
    n2 = keyboard.nextInt();
    System.out.println("Enter the third number");
    n3 = keyboard.nextInt();

    sum = n1 + n2 + n3;
    average = sum / 3;
    System.out.println("The sum of this numbers is: " + sum + " and the average is: " + average);
    }
}
