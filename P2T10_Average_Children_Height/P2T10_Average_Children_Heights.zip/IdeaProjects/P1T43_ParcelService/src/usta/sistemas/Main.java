package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/* AUTHOR: Juan Ricardo Torres Céspedes
	   DATE: 01/04/2020
	   DESCRIPTION: This software determines the shipping cost of 10 different packages (values determined by you).
	 */
    int p1, p2, p3, p4, p5, destiny, total_bill;
    Scanner keyboard= new Scanner(System.in);
    f_menu();
    System.out.println("input the fist product price:");
    p1= keyboard.nextInt();
    System.out.println("input the second product price");
    p2= keyboard.nextInt();
    System.out.println("input the third product price");
    p3= keyboard.nextInt();
    System.out.println("input the fourth product price");
    p4= keyboard.nextInt();
    System.out.println("input the fifth product price");
    p5= keyboard.nextInt();
    System.out.println("input the destiny (1= North America, 2= Central America, 3= South America, 4= Europe, 5=Asia)");
    destiny = keyboard.nextInt();
    total_bill= p1+p2+p3+p4+p5+f_parcel_services(destiny);
    System.out.println("the total bill is: " + total_bill );
    }
    public static void f_menu() {
     //Description: This method/function shows the menu.
        System.out.println("-------------------------------");
        System.out.println("         SoftShippingCost      ");
        System.out.println("    Version: 1.0 - 01/04/2020  ");
        System.out.println("Made by: Juan Ricardo Torres C.");
    }
    public static int f_parcel_services(int p_destiny) {
       //Description: This software calculates the cost of parcel services.
        int valor;
        if (p_destiny==1) {
        valor=11;

        } else if (p_destiny==2) {
            valor=10;
        } else if (p_destiny==3) {
            valor=12;
        } else if (p_destiny==4) {
            valor=24;
        } else if (p_destiny==5) {
            valor=27;
        } else {
            System.out.println("ERRROR: Destiny doesn´t exist");
            valor = 0;
        }
        return valor;
    }
}