package usta.sistemas;

import java.util.Scanner;

public class Main {

    /*  System.out.println("--------------------------------------------");
        System.out.println("        Dr. Coronavirus                     ");
        System.out.println("--------------------------------------------");
        System.out.println("this software determines if you have covid19");
        System.out.println(" created by Juan Ricardo Torres Céspedes    ");
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int tos, dolorcorporal, dificultadrespiratoria, fiebre, edad;
        System.out.println("this software determines if a person has coronavirus");
        System.out.println("the person has to put the number 1 if the question is affirmative and number 2 if the question is negative");
        System.out.println("have you recently had a cough?");
        tos = keyboard.nextInt();
        System.out.println("have you recently had body pain?");
        dolorcorporal = keyboard.nextInt();
        System.out.println("have you recently had respiratory distress?");
        dificultadrespiratoria = keyboard.nextInt();
        System.out.println("please write your body temperature");
        fiebre = keyboard.nextInt();
        System.out.println("please write your age");
        edad = keyboard.nextInt();

        {if  ((tos == 1) && (dolorcorporal == 1) &&
                (dificultadrespiratoria == 1) && (fiebre > 38) &&
                (edad <= 60));
         else {
             System.out.println("you probably have covid19, you should stay isolated and follow the health instructions");
            {
             if ((tos == 1) && (dolorcorporal == 1) &&
                     (dificultadrespiratoria == 1) && (fiebre > 38) &&
                     (edad > 60));
         else {
             System.out.println("you inmediately have to call your eps, you probably have covid19");
                 {
             if (((tos == 1) && (dolorcorporal == 0) &&
                     (dificultadrespiratoria == 0) && (fiebre <= 37)) || edad > 60);
          else {
              System.out.println("you probably don´t have covid19, you should follow the preventive hygiene measures");
        }
              if (tos == 0 && dolorcorporal == 1 &&
                      dificultadrespiratoria == 0 && fiebre <= 37 || edad > 60);
          else {
              System.out.println("you probably don´t have covid19, you should follow the preventive hygiene measures");
        }
              if (tos == 0 && dolorcorporal == 0 &&
                      dificultadrespiratoria == 1 && fiebre <= 37 || edad > 60);
           else {
               System.out.println("you probably don´t have covid19, you should follow the preventive hygiene measures");
        }
               if (tos == 0 && dolorcorporal == 0 &&
                       dificultadrespiratoria == 0 && fiebre > 38 || edad > 60);
            else {
                System.out.println("you probably don´t have covid19, you should follow the preventive hygiene measures");
        }
               if (tos == 0 && dolorcorporal == 0 &&
                       dificultadrespiratoria == 0 && fiebre <= 37 || edad > 60);
             else {
                 System.out.println("you probably don´t have covid19, you should follow the preventive hygiene measures");
        }




    }
}
            }